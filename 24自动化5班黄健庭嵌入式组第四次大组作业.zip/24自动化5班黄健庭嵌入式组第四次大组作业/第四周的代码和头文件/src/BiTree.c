#include <stdio.h>
#include <stdlib.h>
#include <string.h>
 
int Index = -1;

int s_empty(void)
{
    return Index == -1;
}

//?????????
typedef int DataType;
typedef struct node {
	DataType data;	//data
	struct node* left;	//????
	struct node* right;	//?????
}BTnode;
 
BTnode* a[100]; //?

void s_pop(void)
{
    Index--;
}

BTnode* s_top(void)
{
    return a[Index];
}

void s_push(BTnode *p)
{
    Index++;
    a[Index] = p;
}

void pre(BTnode* t) //???????????
{
    BTnode *p = t;
    while(1)
    {
        if(p != NULL){
            s_push(p);
            printf("%d ",p->data);
            p=p->left;
        }else{
            p=s_top();
            s_pop();
            p=p->right;
        }
        if(p == NULL && s_empty()){
            break;
        }
    }
}

void in(BTnode* t) //???????????
{
    BTnode *p = t;
    while(1)
    {
        if(p != NULL){
            s_push(p);
            p=p->left;
        }else{
            p=s_top();
            printf("%d ",p->data);
            s_pop();
            p=p->right;
        }
        if(p == NULL && s_empty()){
            break;
        }
    }
}

void post(BTnode *t)
{
    BTnode *p = t;
    BTnode *r = NULL;   //??????????
    while(p != NULL || !s_empty()){
        if(p!=NULL){
            s_push(p);
            p=p->left;
        }else{
            p=s_top();
            if(p->right == NULL || p->right == r){
                s_pop();
                printf("%d ",p->data);
                r = p;
                p = NULL;
            }else{
                p=p->right;
            }
        }
    }
}
 
//????????????????
void Insert_node(BTnode** root, DataType data) 
{
	if (*root == NULL) {
		*root = (BTnode*)malloc(sizeof(BTnode));	//??��???
		(*root)->data = data;
		(*root)->left = NULL;
		(*root)->right = NULL;
	}
 
	else if ((*root)->data <= data)
		Insert_node(&(*root)->right, data);
	else if ((*root)->data > data)
		Insert_node(&(*root)->left, data);
}
 
 
//??????????
BTnode* Create_sortBtree(DataType* arr, int size) {
	if (!arr)
		return NULL;
	else {
		BTnode* T = NULL;
		for (int i = 0; i < size; i++) {
			Insert_node(&T, arr[i]);
		}
		return T;
	}
}
 
//???????
void InorderTraverse(BTnode* T)
{
	if (!T)
		return;
	InorderTraverse(T->left);
	printf("%d ", T->data);
	InorderTraverse(T->right);
}

//???????
void PostorderTraverse(BTnode* T)
{
	if (!T)
		return;
	PostorderTraverse(T->left);
	PostorderTraverse(T->right);
	printf("%d ", T->data);
}

//???????
void PreorderTraverse(BTnode* T)
{
	if (!T)
		return;
	printf("%d ", T->data);
	PreorderTraverse(T->left);
	PreorderTraverse(T->right);
}
 
//??????
BTnode* Btree_search(BTnode* root, DataType target) {
	if (!root)
		return NULL;
	if (target == root->data) {
		return root;
	}
	return target > root->data ? Btree_search(root->right, target) : Btree_search(root->left, target);
}
 
//??????
void Btree_delete(BTnode** T, DataType l) 
{
    BTnode* p = *T, *f = NULL;
    while (p) {
        if (p->data == l) {
            break;
        }
        f = p; // ????????
        p = l > p->data ? p->right : p->left;
    }

    if (!p) {
        printf("No such node\n");
        return;
    }

    BTnode* target = p; // target?????
    BTnode* par = f;    // par?????

    if (par == NULL && target->left == NULL && target->right == NULL) {
        *T = NULL;
        free(target);
        printf("Deleting successfully\n");
        return;
    }

    //1.?????????
    if (!target->left && target->right != NULL) {
        if (par) { 		// ??????????????
            if (target->data > par->data) {
                par->right = target->right;
            } else {
                par->left = target->right;
            }
        } else {
            *T = target->right;
        }
        free(target);
    }
    //2.?????????
    else if (target->left != NULL && !target->right) {
        if (par) {
            if (target->data > par->data) {
                par->right = target->left;
            } else {
                par->left = target->left;
            }
        } else {
            *T = target->left;
        }
        free(target);
    }
    //3.???????
    else if (!target->left && !target->right) {
            if (target->data > par->data) {
                par->right = NULL;
            } else {
                par->left = NULL;
            }
        free(target);
    }
    //4.??????????????????????????????????????
    else {
        BTnode* Lchild = target->left;
        BTnode* Lchild_par = target;

        while (Lchild->right != NULL) {
            Lchild_par = Lchild;
            Lchild = Lchild->right;
        }
        target->data = Lchild->data;
    
        if (Lchild_par->right == Lchild) {
            Lchild_par->right = Lchild->left;
        } else {
            Lchild_par->left = Lchild->left;
        }
        free(Lchild);
    }
    printf("Deleting successfully\n");
}
 
//?????????
void Destory_btree(BTnode* T) {
	if (!T)
		return;
	BTnode* cur = T;
	if (cur->left)
		Destory_btree(cur->left);
	if (cur->right)
		Destory_btree(cur->right);
	free(T);
}



int main()
{
	int a[] = { 53,17,78,9,45,65,87,23 };
	int index;
	printf("????{ 53,17,78,9,45,65,87,23 }??????????\n");
	BTnode* T = Create_sortBtree(a, sizeof(a) / sizeof(int));
	printf("1???????;2???????;3???????");
	scanf("%d",&index);
	switch(index)
	{
		case 1 : PreorderTraverse(T);break;
		case 2 : InorderTraverse(T);break;
		case 3 : PostorderTraverse(T);break;
		default:printf("error");
	}
	
	printf("\n????????????");
	scanf("%d",&index);
	BTnode* find = Btree_search(T, index);
	printf("?????%d\n", find->data);
 
	printf("\n??????????");
	scanf("%d",&index);
	Btree_delete(&T, index);

	printf("1???????;2???????;3???????");
	scanf("%d",&index);
	switch(index)
	{
		case 1 : PreorderTraverse(T);break;
		case 2 : InorderTraverse(T);break;
		case 3 : PostorderTraverse(T);break;
		default:printf("error");
	}

    printf("\n???????????");
    pre(T);
    printf("\n???????????");
    in(T);
    printf("\n??????????");
    post(T);
	
	Destory_btree(T);

    while(1){}
}