#include <stdio.h>
#include <stdlib.h>

/* 1.单向链表 */
typedef struct node{    //单向链表结构体
    int number;
    struct node *next;
} Node;

Node *CreateCode(int value);    //创建链表新结点 value为新结点数据
void InsertTail(Node** head , int value);    //在链表结尾插入结点
void FreeList(Node *head);   //清除内存
void PrintList(Node *head);   //打印链表


int main()  //定义一个链表，输入-1为结束
{
    int num ;
    Node* Head = NULL;  //初始化链表头
    do{
        scanf("%d",&num);   //读入新结点的数字 若为-1就结束读入
        if(num == -1) {break;}
        else {InsertTail(&Head , num);}    //用函数创建新结
    }while(1);

    PrintList(Head);
    FreeList(Head);

    return 0;
}

Node *CreateCode(int value)     //创建新结点
{
    Node *new = (Node*)malloc(sizeof(Node));    //给链表新结点分配内存
    new->next = NULL;
    new->number = value;
    return new;
}

void InsertTail(Node** head , int value)    //在链表末尾插入结点
{
    Node* newNode = NULL;
    newNode = CreateCode(value);
    if(*head == NULL)   //若为空链表，就将读入数据设置为第一个链表结点
    {
        *head = newNode;
        return;
    }
    Node* temp = *head;
    while (temp->next != NULL)    //找到链表最后一个节点
    {
        temp = temp->next;
    }
    temp->next = newNode;    //将新节点接到链表尾部
}

void FreeList(Node *head)   //清除内存
{
    Node* temp;
    while (head != NULL) {              // 遍历链表并释放每个节点
    temp = head;
    head = head->next;
    free(temp);
    }
}

void PrintList(Node *head)    //打印链表
{
    Node* temp = head;
    while(temp != NULL)
    {
    printf("%d ",temp->number);
    temp = temp->next;
    }
}