#include <stdio.h>
#include <stdlib.h>

/* 2.双向链表 */
typedef struct node{    //双向链表结构体
    int number;
    struct node *next;
    struct node *front;
} Node;

Node *CreateCode(int value);    //创建链表新结点 value为新结点数据
void InsertTail(Node** head , int value);    //在链表结尾插入结点
void InsertHead(Node** head , int value);    //在链表头插入结点
void FreeList(Node *head);   //清除内存
void PrintList(Node *head);   //打印链表
void InsertAtPosition(Node** head);    //插入链表
void DeleteAtPosition(Node** head);     //删除结点


int main()  //定义一个链表，输入-1为结束
{
    int num ;
    Node* Head = NULL;  //初始化链表头
    printf("输入-1插入链表头，输入-2插入链表尾 均为输入-3结束，最后输入-4结束并打印链表\n");
    do{
        int num;

        scanf("%d",&num);

        if(num == -1){
            do{
            scanf("%d",&num);
            if(num == -3){break;}
            InsertHead(&Head , num);
            }while(num != -3);
        }
        else if(num == -2){
            do{
            scanf("%d",&num);
            if(num == -3){break;}
            InsertTail(&Head , num);
            }while(1);
        }
        else if(num == -4){break;}

    }while(1);
    
    PrintList(Head);

    while (num != 4) {
        printf("对链表进行操作，1是对链表进行插入，2是对链表进行删除,3是打印链表，4是退出程序\n");
        scanf("%d", &num);

        switch (num) {
            case 1:
                InsertAtPosition(&Head);
                break;
            case 2:
                DeleteAtPosition(&Head);
                break;
            case 3:
                PrintList(Head);
                break;
            case 4:
                printf("退出程序。\n");
                break;
            default:
                printf("无效的选项，请重新输入。\n");
                break;
        }
    }

    FreeList(Head);

    return 0;
}

Node *CreateCode(int value)     //创建新结点
{
    Node *new = (Node*)malloc(sizeof(Node));    //给链表新结点分配内存
    new->next = NULL;
    new->front = NULL;
    new->number = value;
    return new;
}

void InsertTail(Node** head , int value)    //在链表末尾插入结点
{
    Node* newNode = NULL;
    newNode = CreateCode(value);
    if(*head == NULL)   //若为空链表，就将读入数据设置为第一个链表结点
    {
        *head = newNode;
        return;
    }
    Node* temp = *head;
    while (temp->next != NULL)    //找到链表最后一个节点
    {
        temp = temp->next;
    }
    temp->next = newNode;    //将新节点接到链表尾部

    newNode->front = temp;   //设置新结点的front
}

void InsertHead(Node** head , int value)    //在链表头插入结点
{
    Node* newNode = CreateCode(value);
    
    if(*head == NULL)   //若为空链表，就将读入数据设置为第一个链表结点
    {
        *head = newNode;
        return;
    }

    newNode->next = *head;   //将新结点设置为头结点
    (*head)->front = newNode;
    *head = newNode;
}

void FreeList(Node *head)   //清除内存
{
    Node* temp;
    while (head != NULL) {              // 遍历链表并释放每个节点
    temp = head;
    head = head->next;
    free(temp);
    }
}

void PrintList(Node *head)    //打印链表
{
    Node* temp = head;
    while(temp != NULL)
    {
    printf("%d ",temp->number);
    temp = temp->next;
    }
}

void InsertAtPosition(Node** head) 
{
    printf("插入的位置是第几个：");
    int position;
    scanf("%d", &position);

    if (position < 1) {
        printf("位置无效，请输入正整数位置。\n");
        return;
    }

    printf("插入的数值是什么：");
    int value;
    scanf("%d", &value);

    Node* newNode = CreateCode(value);

    if (position == 1) {        //插入第一个
        newNode->next = *head;
        if (*head != NULL) {
            (*head)->front = newNode;
        }
        *head = newNode;
        return;
    }

    Node* temp = *head;
    int count = 1;

    while (temp != NULL && count < position - 1) {    //遍历到前一个结点
        temp = temp->next;
        count++;
    }

    if (temp == NULL) {
        printf("位置无效，链表长度不足。\n");
        free(newNode);
        return;
    }

    newNode->next = temp->next;
    newNode->front = temp;
    if (temp->next != NULL) {
        temp->next->front = newNode;    //插入结点
    }
    temp->next = newNode;
}

void DeleteAtPosition(Node** head) {
    
    printf("删除的位置是第几个：");
    int position;
    scanf("%d", &position);

    if (position < 1) {
        printf("位置无效，请输入正整数位置。\n");
        return;
    }

    if (*head == NULL) {
        printf("链表为空，无法删除。\n");
        return;
    }

    Node* temp = *head;
    int count = 1; 

    // 遍历到目标位置的节点
    while (temp != NULL && count < position) {
        temp = temp->next;
        count++;
    }

    if (temp == NULL) {
        printf("位置无效，链表长度不足。\n");
        return;
    }

    // 删除节点
    if (temp->front != NULL) {
        temp->front->next = temp->next;
    } else {
        *head = temp->next;  // 如果删除的是头节点
    }

    if (temp->next != NULL) {
        temp->next->front = temp->front;
    }

    free(temp);
    printf("已删除位置为 %d 的节点。\n", position);
}