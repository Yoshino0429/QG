#include <stdio.h>
#include <stdlib.h>

/* 1.单向链表 */
typedef struct node {    //单向链表结构体
    int number;
    struct node *next;
} Node;

Node *CreateCode(int value);    //创建链表新结点 value为新结点数据
void InsertTail(Node** head, int value);    //在链表结尾插入结点
void FreeList(Node *head);   //清除内存
void PrintList(Node *head);   //打印链表
void InsertAtPosition(Node** head);  //插入链表
void DeleteAtPosition(Node** head);   //删除链表

int main()  //定义一个链表，输入-1为结束
{
    printf("输入一个链表,输入一个回车一次，-1以结束输入\n");
    int num;
    Node* Head = NULL;  //初始化链表头
    do {
        scanf("%d", &num);   //读入新结点的数字 若为-1就结束读入
        if (num == -1) break;
        else InsertTail(&Head, num);    //用函数创建新结
    } while (1);

    PrintList(Head);

    while (num != 4) {
        printf("对链表进行操作，1是对链表进行插入，2是对链表进行删除,3是打印链表，4是退出程序\n");
        scanf("%d", &num);

        switch (num) {
            case 1:
                InsertAtPosition(&Head);
                break;
            case 2:
                DeleteAtPosition(&Head);
                break;
            case 3:
                PrintList(Head);
                break;
            case 4:
                printf("退出程序。\n");
                break;
            default:
                printf("无效的选项，请重新输入。\n");
                break;
        }
    }

    FreeList(Head);
    return 0;
}

Node *CreateCode(int value)     //创建新结点
{
    Node *new = (Node*)malloc(sizeof(Node));    //给链表新结点分配内存
    new->next = NULL;
    new->number = value;
    return new;
}

void InsertTail(Node** head, int value)    //在链表末尾插入结点
{
    Node* newNode = CreateCode(value);
    if (*head == NULL) {   //若为空链表，就将读入数据设置为第一个链表结点
        *head = newNode;
        return;
    }
    Node* temp = *head;
    while (temp->next != NULL) {    //找到链表最后一个节点
        temp = temp->next;
    }
    temp->next = newNode;    //将新节点接到链表尾部
}

void FreeList(Node *head)   //清除内存
{
    Node* temp;
    while (head != NULL) {              // 遍历链表并释放每个节点
        temp = head;
        head = head->next;
        free(temp);
    }
}

void PrintList(Node *head)    //打印链表
{
    Node* temp = head;
    while (temp != NULL) {
        printf("%d ", temp->number);
        temp = temp->next;
    }
    printf("\n");
}

void InsertAtPosition(Node** head) 
{
    printf("插入的位置是第几个：");
    int position;
    scanf("%d", &position);

    if (position < 1) {
        printf("位置无效，请输入正整数位置。\n");
        return;
    }

    printf("插入的数值是什么：");
    int value;
    scanf("%d", &value);

    Node* newNode = CreateCode(value);  // 创建新节点
    if (position == 1) {        // 在头部插入
        newNode->next = *head;
        *head = newNode;
        return;
    }

    Node* temp = *head;
    int count = 1;

    // 遍历到目标位置的前一个节点
    while (temp != NULL && count < position - 1) {
        temp = temp->next;
        count++;
    }

    if (temp == NULL) {
        printf("位置无效，链表长度不足。\n");
        free(newNode);
        return;
    }

    newNode->next = temp->next;     // 插入新节点
    temp->next = newNode;
}

void DeleteAtPosition(Node** head) {
    printf("请输入要删除的节点位置：");
    int position;
    scanf("%d", &position);

    if (position < 1) {
        printf("位置无效，请输入正整数位置。\n");
        return;
    }

    if (*head == NULL) {
        printf("链表为空，无法删除。\n");
        return;
    }

    Node* temp2 = *head;
    Node* temp1 = NULL;

    if (position == 1) {
        *head = temp2->next;
        free(temp2);
        return;
    }

    int count = 1;      // 遍历到目标位置的节点
    while (temp2 != NULL && count < position) {
        temp1 = temp2;
        temp2 = temp2->next;
        count++;
    }

    if (temp2 == NULL) {
        printf("位置无效，链表长度不足。\n");
        return;
    }

    temp1->next = temp2->next;
    free(temp2);
    printf("已删除位置为 %d 的节点。\n", position);
}