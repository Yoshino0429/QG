#ifndef _LINKSTACK_H_
#define _LINKSTACK_H_

typedef struct node {    //单向链表结构体
    int number;
    struct node *next;
} Node;

typedef struct LinkStack {      //链栈结构体
    Node* top;  
    int count;
}LinkStack;

LinkStack* LinkStack_Init(void);     //初始化链栈
int LinkStack_Length(LinkStack *Stack);
void LinkStack_Clear(LinkStack *Stack);
void LinkStack_Push(LinkStack* LS,int value);
void LinkStack_Print(LinkStack *LS);
int LinkStack_IsEmpty(LinkStack *Stack);
void LinkStack_Destory(LinkStack* Stack);
int LinkStack_GetTop(LinkStack* Stack);
void LinkStack_Pop(LinkStack* Stack);

#endif