#ifndef _CALCULATOR_H_
#define _CALCULATOR_H_

int expcompute(char *e);

#endif