#ifndef _LINKSTACK_H_
#define _LINKSTACK_H_

typedef struct node {
    char data;
    struct node *next;
} Node;

typedef struct LinkStack {
    Node* top;  
    int count;
}LinkStack;

LinkStack* LinkStack_Init(void);
int LinkStack_Length(LinkStack *Stack);
void LinkStack_Clear(LinkStack *Stack);
void LinkStack_Push(LinkStack* LS,int value);
void LinkStack_Print(LinkStack *LS);
int LinkStack_IsEmpty(LinkStack *Stack);
void LinkStack_Destory(LinkStack* Stack);
int LinkStack_GetTop(LinkStack* Stack);
int LinkStack_Pop(LinkStack* Stack);

#endif