#include <stdio.h>
#include <stdlib.h>

/* 1.�������� */
typedef struct node {    //���������ṹ��
    int number;
    struct node *next;
} Node;

typedef struct LinkStack {
    Node* top;
    int count;
}LinkStack;

LinkStack* LinkStack_Init(void)     //��ʼ����ջ
{
    Node* Top = (Node*)malloc(sizeof(Node));
    Top->next = NULL;
    LinkStack* new = (LinkStack*)malloc(sizeof(LinkStack));
    new->top = Top;
    new->count = 0;
    return new;
}

Node *CreateCode(int value);    //���������½�� valueΪ�½������
void InsertTail(Node** head, int value);    //��������β������
void FreeList(Node *head);   //����ڴ�
void PrintList(Node *head);   //��ӡ����
void InsertAtPosition(Node** head);  //��������
void DeleteAtPosition(Node** head);   //ɾ������

int LinkStack_Length(LinkStack *Stack)
{
    return Stack->count;
}

void LinkStack_Clear(LinkStack *Stack)
{
    if(Stack->top->next == NULL){return;}
    FreeList(Stack->top->next);  
}

void LinkStack_Push(LinkStack* LS,int value)
{
    Node* new = CreateCode(value);
    new->next = LS->top->next;
    LS->top->next = new;
    LS->count = LS->count + 1;
}

void LinkStack_Print(LinkStack *LS)
{
    if(LS->top->next == NULL){printf("error\n");return;}
    int i = LS->count;
    Node* node = LS->top->next;
    
    while(node != NULL)
    {
        printf("%d ",node->number);
        node = node->next;
    }
    printf("\n");
}

int LinkStack_IsEmpty(LinkStack *Stack)
{
    if(Stack->top->next == NULL){return 1;}
    if(Stack->top->next != NULL){return 0;}
}

void LinkStack_Destory(LinkStack* Stack)
{
    FreeList(Stack->top->next);
    free(Stack->top);
    free(Stack);
}

int LinkStack_GetTop(LinkStack* Stack)
{
    if(Stack->top->next == NULL){return -1;}
    int top = Stack->top->next->number;
    return top;
}

int LinkStack_Pop(LinkStack* Stack)
{
    if(Stack->top->next == NULL){printf("error\n");return;}
    int num;
    Node* temp = Stack->top->next;
    num = temp->number;
    Stack->top->next = Stack->top->next->next;
    Stack->count -= 1;
    free(temp);
    return num;
}

Node *CreateCode(int value)     //�����½��
{
    Node *new = (Node*)malloc(sizeof(Node));    //�������½������ڴ�
    new->next = NULL;
    new->number = value;
    return new;
}

void FreeList(Node *head)   //����ڴ�
{
    Node* temp;
    while (head != NULL) {              // �����������ͷ�ÿ���ڵ�
        temp = head;
        head = head->next;
        free(temp);
    }
}
