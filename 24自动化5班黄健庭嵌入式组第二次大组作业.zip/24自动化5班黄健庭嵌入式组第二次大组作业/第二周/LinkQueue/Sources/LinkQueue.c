#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node {    //单向链表结构体
    void* data;
    struct node *next;
} Node;

typedef struct LinkQueue {  //队列结构体
    Node* front;
    Node* rear;
    int length;
}LinkQueue;

LinkQueue* LinkQueue_Init(void) 
{
    LinkQueue* q = (LinkQueue*)malloc(sizeof(LinkQueue));
    q->front = NULL;
    q->rear = NULL;
    q->length = 0;
    return q;
}

Node *CreateCode(void* value)     //创建新结点
{
    Node *new = (Node*)malloc(sizeof(Node));    //给链表新结点分配内存
    new->next = NULL;
    new->data = value;
    return new;
}

void LinkQueue_En(LinkQueue* q, void* data)     //入队
{
    Node* new = CreateCode(data);

    if (q->rear == NULL) { // 若队尾即队列为空
        q->front = q->rear = new;
    } else {
        q->rear->next = new;    //插入队尾
        q->rear = new;
    }

    q->length += 1;
}

void* LinkQueue_De(LinkQueue* q)    //出队
{
    if (q->front == NULL) {     //头节点即队尾为空
        printf("error\n");
        return NULL;
    }
    Node* temp = q->front;
    void* data = temp->data;
    q->front = q->front->next;

    if (q->front == NULL) { //在只剩下一个结点的情况下，front释放了会导致rear指向未定义地址
        q->rear = NULL;
    }
    free(temp);
    q->length -= 1;
    return data;
}

int LinkQueue_IsEmpty(LinkQueue* q) 
{
    return q->front == NULL;    //队列即队尾是否为空
}


void LinkQueue_Clear(LinkQueue* q)  // 逐个释放节点
{
    while (!LinkQueue_IsEmpty(q)) {
        LinkQueue_De(q);
    }
}

int LinkQueue_Length(LinkQueue *q)
{
    return q->length;
}

void LinkQueue_Destory(LinkQueue* q) 
{
    while (!LinkQueue_IsEmpty(q)) {   //若q队列不为空
        LinkQueue_De(q); // 逐个释放节点，释放完一个队尾会更新，继续行判断，直到队尾是空
    }
    free(q); // 释放队列结构本身
}

void LinkQueue_Print(LinkQueue* q, void (*printData)(void*)) // 调用用户提供的打印函数
{
    if (q->front == NULL) 
    {
        printf("队列为空无法打印喵\n");
        return;
    }

    Node* current = q->front;
    while (current != NULL) {
        printData(current->data); 
        printf(" ");
        current = current->next;
    }
    printf("\n");
}

void printIntData(void* data) 
{
    int* value = (int*)data;
    printf("%d", *value);
}

void printStringData(void* data) 
{
    char* str = (char*)data;
    printf("%s", str);
}

int main()
{
    LinkQueue* LQ = LinkQueue_Init();
    printf("已默认初始化链式队列\n");
    int index1,index2;
    printf("选择存储类型:1-int 2-string\n");
    scanf("%d", &index1);
    while(1)
    {
    printf("要进行的操作是:1-入队 2-出队 3-清空队 4-打印队 5-判断空 6-输出长度 -1-退出(即销毁队)\n");
    scanf("%d",&index2);
    if(index2 == -1){LinkQueue_Destory(LQ);break;}
    switch(index2){
        case 1:

        if(index1 == 1)
        {
            int num;
            int* numPtr = (int*)malloc(sizeof(int));
            while(1)
            {   
                printf("输入int数，-1停止输入:");
                scanf("%d", &num);
                if(num == -1) { break; }
                numPtr = (int*)malloc(sizeof(int));
                *numPtr = num;
                LinkQueue_En(LQ,numPtr);
            }free(numPtr);
            }else{
                char* str;
                while(1)
                {
                    printf("输入字符串，-1停止输入:");
                    str = (char*)malloc(100 * sizeof(char)); // 分配动态内存
                    scanf("%s", str);
                    if(strcmp(str, "-1") == 0) 
                    {
                        free(str);
                        break;
                    }
                    LinkQueue_En(LQ, str);
                }
        }break;

        case 2:LinkQueue_De(LQ);break;
        case 3:LinkQueue_Clear(LQ);break;
        case 4:
        if(index1 == 1)
        {
            LinkQueue_Print(LQ, printIntData);
            }else{
                LinkQueue_Print(LQ, printStringData);
                }break;
        case 5:if(LinkQueue_IsEmpty(LQ) == 1){printf("空\n");}else{printf("不为空\n");};break;
        case 6:printf("%d\n",LinkQueue_Length(LQ));break;
        default:printf("error");continue;
    }
    }
    return 0;
}