#include <REGX52.H>
#include "intrins.h"


#define FOSC 11059200L      //System frequency
#define BAUD 9600           //UART baudrate

unsigned char wei[] = {0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07};
unsigned char num[] = {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};

void Timer0Init(void)		//1毫秒@12.000MHz
{
	TMOD &= 0xF0;		//设置定时器模式
	TMOD |= 0x01;		//设置定时器模式
	TL0 = 0x18;		//设置定时初值
	TH0 = 0xFC;		//设置定时初值
	TF0 = 0;		//清除TF0标志
	TR0 = 1;		//定时器0开始计时
    ET0 = 1;
    EA = 1;     //打开中断通路
}
    
unsigned int Tcnt = 0;
unsigned int i = 0;

void SendData(unsigned char dat)
{
    SBUF = dat;             //Send data to UART buffer
    while(TI==0);   //wait for TI == 1
	TI=0;
}

void SendString(char *s)
{
    while (*s)
    {
        SendData(*s++);
    }
}

void Timer0_UART() interrupt 1
{
    
    TL0 = 0x18;		//设置定时初值
	TH0 = 0xFC;		//设置定时初值
    Tcnt++;
    if(Tcnt == 1000)
    {
    
    
    Tcnt = 0;
    }
}

void UART_Init(void)
{
    SCON = 0x50;            //8bit
    TMOD = 0x20;            //8位自动重载
    TH1 = TL1 = -(FOSC/12/32/BAUD); //自动重载数
    TR1 = 1;                //打开Timer1
    ES = 1;                 //使能串口中断
    EA = 1; 
}



void main()
{
    UART_Init();  
    Timer0Init();
    P3_5 = 0;
    P3_6 = 0;
    P3_7 = 0;
    while(1)
    {
        
    }
}

void UART_Routine() interrupt 4     //只做了一位数字的显示
{
    if(RI == 1)
    {
        SendData(SBUF);
        SendString("Received\r\n");
        P2 = num[SBUF - '0'];
        RI = 0;
    }
}

