#include <REGX52.H>
#include "intrins.h"


#define FOSC 11059200L      //System frequency
#define BAUD 9600           //UART baudrate

void Timer0Init(void)		//1毫秒@12.000MHz
{
	TMOD &= 0xF0;		//设置定时器模式
	TMOD |= 0x01;		//设置定时器模式
	TL0 = 0x18;		//设置定时初值
	TH0 = 0xFC;		//设置定时初值
	TF0 = 0;		//清除TF0标志
	TR0 = 1;		//定时器0开始计时
    ET0 = 1;
    EA = 1;     //打开中断通路
}
    
unsigned int Tcnt = 0;
unsigned int i = 0;

void SendData(unsigned char dat)
{
    SBUF = dat;             //Send data to UART buffer
    while(TI==0);   //wait for TI == 1
	TI=0;
}

void SendString(char *s)
{
    while (*s)
    {
        SendData(*s++);
    }
}

void Timer0_UART() interrupt 1
{
    
    TL0 = 0x18;		//设置定时初值
	TH0 = 0xFC;		//设置定时初值
    Tcnt++;
    if(Tcnt == 1000)
    {
    SendString("HELLOWORLD\r\n");
    
    Tcnt = 0;
    }
}

void UART_Init(void)
{
    SCON = 0x50;            //8bit
    TMOD = 0x20;            //8位自动重载
    TH1 = TL1 = -(FOSC/12/32/BAUD); //自动重载数
    TR1 = 1;                //打开Timer1
    ES = 1;                 //使能串口中断
    EA = 1; 
}



void main()
{
    UART_Init();  
    Timer0Init();
    while(1)
    {
        
    }
}

