#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void sortDataFromFile(const char* filename, void (*sortFunc)(int arr[], int size)) 
{
    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        printf("无法打开文件 %s\n", filename);
        return;
    }

    // 读取文件中的数据
    int dataSize = 0;
    int buffer;
    while (fscanf(file, "%d", &buffer) != EOF) {
        dataSize++;
    }
    rewind(file); // 重置文件指针到文件开头

    int* data = (int*)malloc(dataSize * sizeof(int));
    if (data == NULL) {
        printf("内存分配失败\n");
        fclose(file);
        return;
    }

    for (int i = 0; i < dataSize; i++) {
        fscanf(file, "%d", &data[i]);
    }
    fclose(file);

    // 调用排序函数
    sortFunc(data, dataSize);

    // 输出排序结果
    printf("排序结果：\n");
    for (int i = 0;i < dataSize; i++) { // 只显示前10个数据
        printf("%d ", data[i]);
    }

    free(data);
}

void CountingSort(int a[],int length)
{
    if(length < 2)
        return;
    
    int i;
    int max = a[0];
    for(i=0;i<length;i++)
        if(a[i]>max){max = a[i];}
    
    int *count = (int*)malloc((max+1)*sizeof(int));
    memset(count,0,(max+1)*sizeof(int));

    for(i=0;i<length;i++)   //count
    {
        count[a[i]]++;
    }
    
    for(i=1;i<max+1;i++)    //accmulation
    {
        count[i] += count[i - 1];
    }

    int *tempArr = (int*)malloc(length*sizeof(int));
    
    for(i=0;i<length;i++)
    {
            tempArr[count[a[i]]-1] = a[i];
            count[a[i]]--;
    }

    for(i=0;i<length;i++)
    {
        a[i] = tempArr[i];
    }
}

int main()
{
    sortDataFromFile("TempFile", CountingSort) ;
    while(1)
    {
        
    }
}