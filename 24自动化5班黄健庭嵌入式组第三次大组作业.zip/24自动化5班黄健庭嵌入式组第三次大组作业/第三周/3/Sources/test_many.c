#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

// 测试大量小数据量下的排序用时
void test_small_data_sorting(void (*sort_func)(int[], int), const char* sort_name)
{
    int small_size = 100; // 每组数据的大小
    int num_tests = 100000; // 测试次数

    // 动态分配数组存储小数据规模的随机数据
    int* arr = (int*)malloc(small_size * sizeof(int));
    if (!arr) {
        printf("Memory allocation failed.\n");
        return;
    }

    clock_t total_time = 0; // 用于累加总时间

    // 进行多次测试
    for (int i = 0; i < num_tests; i++) {
        // 随机生成小范围数据
        for (int j = 0; j < small_size; j++) {
            arr[j] = rand() % 1000; // 生成0-999随机数
        }

        // 复制数组用于排序
        int* test_arr = (int*)malloc(small_size * sizeof(int));
        if (!test_arr) {
            printf("Memory allocation failed.\n");
            free(arr);
            return;
        }
        memcpy(test_arr, arr, small_size * sizeof(int)); // 复制数据

        // 记录排序时间
        clock_t start_time = clock(); // 获取排序开始时间
        sort_func(test_arr, small_size); // 调用排序函数
        clock_t end_time = clock(); // 获取排序结束时间
        total_time += (end_time - start_time); // 累加排序时间

        // 释放动态分配的内存
        free(test_arr);
    }

    printf("在100个数据量下%s排序100k次一共使用%.6f秒\n",sort_name, (double)total_time / CLOCKS_PER_SEC);

    // 释放动态分配的内存
    free(arr);
}