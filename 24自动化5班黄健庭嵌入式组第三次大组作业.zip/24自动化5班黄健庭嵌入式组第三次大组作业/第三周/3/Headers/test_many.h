#ifndef TEST_MANY_H
#define TEST_MANY_H

void test_small_data_sorting(void (*sort_func)(int[], int), const char* sort_name);

#endif