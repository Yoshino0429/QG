#ifndef TEST_LARGE_H
#define TEST_LARGE_H

void test_large_data_sorting(void (*sort_func)(int[], int), const char* sort_name);

#endif
