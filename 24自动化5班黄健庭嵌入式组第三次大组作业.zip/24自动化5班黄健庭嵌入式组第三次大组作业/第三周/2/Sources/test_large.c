#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

// 测试不同大数据量下的排序用时
void test_large_data_sorting(void (*sort_func)(int[], int), const char* sort_name) 
{
    int data_sizes[] = {10000, 50000, 200000};
    int num_tests = 3;

    // 遍历每个数据规模
    for (int a = 0; a < num_tests; a++) {
        int size = data_sizes[a]; // 当前数据规模
        int* arr = (int*)malloc(size * sizeof(int));
        if (!arr) {
            printf("Memory allocation failed.\n");
            return;
        }

        // 随机生成数据
        for (int b = 0; b < size; b++) {
            arr[b] = rand() % 1000; // 生成0-999随机数
        }

        // 复制数组用于排序
        int* test_arr = (int*)malloc(size * sizeof(int));
        if (!test_arr) {
            printf("Memory allocation failed.\n");
            free(arr);
            return;
        }
        memcpy(test_arr, arr, size * sizeof(int)); // 复制数据

        // 记录排序时间
        clock_t start_time = clock(); // 获取开始时间
        sort_func(test_arr, size);    // 调用排序函数
        clock_t end_time = clock();   // 获取结束时间
        double time = (double)(end_time - start_time) / CLOCKS_PER_SEC; // 计算排序用时

        // 输出排序结果
        printf(" 在%d数据量下%s使用了%.6f秒.\n", size, sort_name, time);

        // 释放动态分配的内存
        free(test_arr);
        free(arr);
    }
}