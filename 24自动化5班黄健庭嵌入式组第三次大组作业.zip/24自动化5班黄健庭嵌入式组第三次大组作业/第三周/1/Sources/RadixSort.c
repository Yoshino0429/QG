#include <stdio.h>

void printArr(int a[],int length)
{
    int i;
    for(i=0;i<length;i++)
    {
        printf("%d ",a[i]);
    }
    printf("\n");
}

int b[10][100];   //桶

int Digit(int n)    //求位数
{
    int k = 0;
    while(n != 0)
    {
        n = n/10;
        k++;
    }
    return k;
}

int maxDigit(int a[],int length)
{
   int i;
   int max = 0;
   for(i=0;i<length;i++)
   {
    if(a[i] > max){max = a[i];}
   }
   return Digit(max);
}

void RadixSort(int a[], int length) {
    int digit = maxDigit(a, length);    // 获取最大位数
    int Y = 1;  // 当前位数

    for (int i = 0; i < digit; i++) {
        // 初始化桶
        for (int j = 0; j < 10; j++) {
            b[j][0] = 0;    // 每个桶的大小初始化为 0
        }

        // 将元素放入桶中
        for (int j = 0; j < length; j++) {
            int temp = (a[j] / Y) % 10; // 计算当前位的值
            b[temp][++b[temp][0]] = a[j]; // 放入对应的桶中
        }

        // 将桶中的元素放回数组 a
        int a_length = 0; // 当前已排序的元素数量
        for (int j = 0; j < 10; j++) { // 遍历所有桶
            for (int k = 1; k <= b[j][0]; k++) { // 遍历桶中的元素
                a[a_length++] = b[j][k];
            }
        }

        printArr(a,5);

        Y *= 10; // 增加权重，处理下一位
    }
}

int main()
{
    int a[]={4324,523544,765,42398,123};
    RadixSort(a,5);
    printArr(a,5);
}