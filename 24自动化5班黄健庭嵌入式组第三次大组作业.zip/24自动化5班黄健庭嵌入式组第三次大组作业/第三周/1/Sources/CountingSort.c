#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void CountingSort(int a[],int length)
{
    if(length < 2)
        return;
    
    int i;
    int max = a[0];
    for(i=0;i<length;i++)
        if(a[i]>max){max = a[i];}
    
    int *count = (int*)malloc((max+1)*sizeof(int));
    memset(count,0,(max+1)*sizeof(int));

    for(i=0;i<length;i++)   //count
    {
        count[a[i]]++;
    }
    
    for(i=1;i<max+1;i++)    //accmulation
    {
        count[i] += count[i - 1];
    }

    int *tempArr = (int*)malloc(length*sizeof(int));
    
    for(i=0;i<length;i++)
    {
            tempArr[count[a[i]]-1] = a[i];
            count[a[i]]--;
    }

    for(i=0;i<length;i++)
    {
        a[i] = tempArr[i];
    }
}

void printArr(int a[],int length)
{
    int i;
    for(i=0;i<length;i++)
    {
        printf("%d ",a[i]);
    }
    printf("\n");
}


int main()
{
    int a[]={4,2,5,7,32432423,4,12,5};
    printArr(a,8);
    CountingSort(a,8);
    printArr(a,8);
}