#include <stdio.h>

int Partition(int a[],int low,int high)
{
    int pivot = a[low];
    while(low<high)
    {
        while(low<high && a[high] >=pivot)
            high--;
        a[low] = a[high];
        while(low<high && a[low] <= pivot)
            low++;
        a[high] = a[low];
    }
    a[low]=pivot;
    return low;
}

void QuickSort(int a[],int low,int high)    
{
    if(low<high)
    {
        int pivotpos = Partition(a,low,high);
        QuickSort(a,low,pivotpos-1);
        QuickSort(a,pivotpos+1,high);
    }
}

void printArr(int a[],int length)
{
    int i;
    for(i=0;i<length;i++)
    {
        printf("%d ",a[i]);
    }
    printf("\n");
}

int main()
{
    int a[]={2,3,6,3,8,3,7,9,1};
    QuickSort(a,0,8);
    printArr(a,9);
}