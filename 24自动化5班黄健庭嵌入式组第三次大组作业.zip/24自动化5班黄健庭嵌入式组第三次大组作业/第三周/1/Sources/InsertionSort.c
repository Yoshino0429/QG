#include <stdio.h>

void InsertionSort(int a[],int length)
{
    int i;
    for(i=1;i<length;i++)
    {
        int t = a[i];
        int j = i - 1;
        while(j>=0 && a[j]>t)
        {
            a[j+1] =a[j];
            a[j] = t;
            j--;
        }
    }
}

void printArr(int a[],int length)
{
    int i;
    for(i=0;i<length;i++)
    {
        printf("%d ",a[i]);
    }
    printf("\n");
}

int main()
{
    int a[] = {5254,4,454236,-1,4,5};
    printArr(a,6);
    InsertionSort(a,6);
    printArr(a,6);
}